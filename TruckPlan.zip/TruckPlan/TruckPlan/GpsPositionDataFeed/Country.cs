﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GpsPositionDataFeed
{
    public enum Country
    {
        None = 0,
        Denmark = 1,
        Germany = 2

    }
}
