﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GpsPositionDataFeed
{
    public interface IPositionFeed
    {
        Position[] GetPositionsByDevice(int deviceId, DateTime? from , DateTime? to );
    }
}
    