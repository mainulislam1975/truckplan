﻿using System;
using System.Collections.Generic;
using System.Device.Location;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GpsPositionDataFeed
{
    public class StaticPositionRepository : IPositionRepository
    {
        public Position[] GetPositionsAll()
        {
            return new[] {
                    new Position() {
                        Coordinate =  new GeoCoordinate(){  Latitude = 32.9697, Longitude = 25.80322},
                        Timestamp = DateTime.Now.AddMinutes(-15),
                         Device = new GpsDevice(){ DeviceId = 1} ,
                         Country = Country.Germany
                         },

                        new Position() {
                        Coordinate =  new GeoCoordinate(){  Latitude = 29.46786, Longitude = 26.53506},
                        Timestamp = DateTime.Now.AddMinutes(-10),
                        Device = new GpsDevice(){ DeviceId = 1} ,
                         Country = Country.Germany
                         },

                        new Position() {
                        Coordinate =  new GeoCoordinate(){  Latitude = 26.9697, Longitude = 27.80322},
                        Timestamp = DateTime.Now.AddMinutes(-5),
                        Device = new GpsDevice(){ DeviceId = 1} ,
                        Country = Country.Germany
                         },
                        new Position() {
                        Coordinate =  new GeoCoordinate(){  Latitude = 24.9697, Longitude = 29.80322},
                        Timestamp = DateTime.Now,
                        Device = new GpsDevice(){ DeviceId = 1} ,
                        Country = Country.Denmark
                        },
                        new Position() {
                        Coordinate =  new GeoCoordinate(){  Latitude = 43.7534932, Longitude = 28.5743187},
                        Timestamp = DateTime.Now.AddMinutes(-20),
                        Device = new GpsDevice(){ DeviceId = 2} ,
                        Country = Country.Germany,
                        },
                        new Position() {
                        Coordinate =  new GeoCoordinate(){  Latitude = 44.7534932, Longitude = 29.5743187},
                        Timestamp = DateTime.Now.AddMinutes(-15),
                        Device = new GpsDevice(){ DeviceId = 2} ,
                        Country = Country.Germany,
                        },
                        new Position() {
                        Coordinate =  new GeoCoordinate(){  Latitude = 44.7534932, Longitude = 29.5743187},
                        Timestamp = DateTime.Now.AddMinutes(-10),
                        Device = new GpsDevice(){ DeviceId = 2} ,
                        Country = Country.Germany,
                        },
                        new Position() {
                        Coordinate =  new GeoCoordinate(){  Latitude = 46.7534932, Longitude = 31.5743187},
                        Timestamp = DateTime.Now.AddMinutes(-5),
                        Device = new GpsDevice(){ DeviceId = 2} ,
                        Country = Country.Germany,
                        },
                        new Position() {
                        Coordinate =  new GeoCoordinate(){  Latitude = 47.7534932, Longitude = 32.5743187},
                        Timestamp = DateTime.Now,
                        Device = new GpsDevice(){ DeviceId = 2} ,
                        Country = Country.Germany,
                        },

                        
                        new Position() {
                        Coordinate =  new GeoCoordinate(){  Latitude = 43.7534932, Longitude = 28.5743187},
                        Timestamp = new DateTime(2018, 2, 3, 7,0,0),
                        Device = new GpsDevice(){ DeviceId = 3} ,
                        Country = Country.Germany,
                        },
                        new Position() {
                        Coordinate =  new GeoCoordinate(){  Latitude = 44.7534932, Longitude = 29.5743187},
                        Timestamp = new DateTime(2018, 2, 3, 12 , 0, 0),
                        Device = new GpsDevice(){ DeviceId = 3} ,
                        Country = Country.Germany,
                        },
                        new Position() {
                        Coordinate =  new GeoCoordinate(){  Latitude = 44.7534932, Longitude = 29.5743187},
                        Timestamp = new DateTime(2018, 2, 4, 1,0,0),
                        Device = new GpsDevice(){ DeviceId = 3} ,
                        Country = Country.Germany,
                        },
                        new Position() {
                        Coordinate =  new GeoCoordinate(){  Latitude = 46.7534932, Longitude = 31.5743187},
                        Timestamp = new DateTime(2018, 2, 5,5,0,0),
                        Device = new GpsDevice(){ DeviceId = 4} ,
                        Country = Country.Germany,
                        },
                        new Position() {
                        Coordinate =  new GeoCoordinate(){  Latitude = 47.7534932, Longitude = 32.5743187},
                        Timestamp = new DateTime(2018, 2, 6, 5,0,0),
                        Device = new GpsDevice(){ DeviceId = 4} ,
                        Country = Country.Germany,
                        },

                };
        }
    }
}
