﻿using System;
using System.Collections.Generic;
using System.Device.Location;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GpsPositionDataFeed
{
    public class PositionFeed : IPositionFeed
    {
        private readonly IPositionRepository _positionRepository;
        public PositionFeed(IPositionRepository positionRepository)
        {
            _positionRepository = positionRepository ?? throw new ArgumentNullException(nameof(positionRepository));
        }
        public Position[] GetPositionsByDevice(int deviceId, DateTime? from = null, DateTime? to = null)
        {
            var positions = _positionRepository.GetPositionsAll();
            return positions.ToList().FindAll(x => 
                                                x.Device.DeviceId == deviceId  && 
                                                (!from.HasValue || x.Timestamp >= from.Value) &&
                                                (!to.HasValue || x.Timestamp <= to.Value)


            ).ToArray();
        }

    }
}
