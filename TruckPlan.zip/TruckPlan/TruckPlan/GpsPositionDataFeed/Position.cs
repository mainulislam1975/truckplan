﻿using System;
using System.Collections.Generic;
using System.Device.Location;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GpsPositionDataFeed
{
    public class Position
    {
        public GpsDevice Device { get; set; }
        public GeoCoordinate Coordinate { get; set; }

        public DateTime Timestamp { get; set; } //UTC DateTime

        public Country? Country { get; set; }

        //TODO: implement IComparable so that list of positions can be sorted ascending using timestamp.


    }
}
