﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TruckPlan.Domain
{
    public class TruckDrivePlan
    {
        public int Id { get; set; }
        public Truck Truck { get; set; }
        public Driver Driver { get; set; }      

        public DateTime? started { get; set; }
        public DateTime? completed { get; set; }

        public bool HasStarted => started.HasValue && started.Value <= DateTime.UtcNow;
        public bool HasCompleted => completed.HasValue && completed.Value <= DateTime.UtcNow;

        public double? distanceKM { get; set; }

    }
}
