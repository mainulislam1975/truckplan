﻿using GpsPositionDataFeed;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TruckPlan.Domain
{
    public class Truck
    {
        public int TruckId { get; set; }
        public GpsDevice GpsDevice { get; set; }


    }
    }

