﻿using GpsPositionDataFeed;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TruckPlan.Domain;
using TruckPlan.Infrastructure;
using Unity;

namespace TruckPlan
{
    class Program
    {
        static void Main(string[] args)
        {
            /* Creating microsoft unity Container*/
            UnityContainer IU = new UnityContainer();


            /* Register a type with specific members to be injected. */

            IU.RegisterType<IPositionFeed, PositionFeed>();
            IU.RegisterType<ITruckPlanDataRepository, StaticTruckDrivePlanRepository>();
            IU.RegisterType<IPositionRepository, StaticPositionRepository>();

            DistanceCalculator objDC = IU.Resolve<DistanceCalculator>();
            Console.WriteLine($"Approximate distance for truck drive plan 1 is  {objDC.GetDistance(1)} kilometer"); 
            

            Console.WriteLine($"Approximate distance for truck drive plan 2 is  {objDC.GetDistance(2)} kilometer");
            

            Console.WriteLine($"Country of the starting point of the truck drive plan 1");
            Console.WriteLine($"How many kilometers  drivers over the age of 50 drove in Germany in February 2018 ? Answer would be {objDC.GetKilometersInGermanyDrivenByDriversOver50InFeb2018()}");
            Console.ReadLine();
            
        }
    }
}
