﻿using GpsPositionDataFeed;
using System;
using System.Collections.Generic;
using System.Device.Location;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TruckPlan.Infrastructure;

namespace TruckPlan.Domain
{
    public class DistanceCalculator
    {
        private readonly IPositionFeed _positionFeed;
        private readonly ITruckPlanDataRepository _repository;
        public DistanceCalculator(IPositionFeed positionFeed, ITruckPlanDataRepository repository)
        {
            _positionFeed = positionFeed ?? throw new ArgumentNullException(nameof(positionFeed));
            _repository = repository ?? throw new ArgumentNullException(nameof(repository));

        }

        public  double GetDistance(int TruckDrivePlanId)
        {
            var drive = _repository.GetTruckDrivePlans().First(x => x.Id == TruckDrivePlanId);
            if (drive is null) throw new ArgumentOutOfRangeException();
            var positions = _positionFeed.GetPositionsByDevice(drive.Truck.GpsDevice.DeviceId, drive.started, drive.completed);           
            return CalculateDistance(positions);

        }

        public double GetKilometersInGermanyDrivenByDriversOver50InFeb2018()
        {
            //Get all truckplans driven by drivers over 50
            var drivePlansAll = _repository.GetTruckDrivePlans();
            var drivePlanInFeb2018 = drivePlansAll.Where(x => x.HasStarted &&
                                                (
                                                 (x.started >= new DateTime(2018, 2, 1) && x.started <= new DateTime(2018, 2, 28, 23, 59, 59)) ||
                                                 (x.completed >= new DateTime(2018, 2, 1) && x.completed <= new DateTime(2018, 2, 28, 23, 59, 59))
                                                ) &&
                                                x.Driver.DateOfBirth < DateTime.Today.AddYears(-50)
                                                
                                                );
            double grandTotalDistance = 0;

            foreach (var plan in drivePlanInFeb2018)
            {               
                var positions = _positionFeed.GetPositionsByDevice(plan.Truck.GpsDevice.DeviceId, plan.started, plan.completed);
                positions = positions.ToList().FindAll(x => x.Country == Country.Germany).ToArray();
                grandTotalDistance += CalculateDistance(positions);

            }
             return grandTotalDistance;

        }

        

        private static double CalculateDistance(Position[] positions)
        {
            GeoCoordinate startlocation = null;
            double distanceKM = 0;
            positions = positions.ToList().OrderBy(x => x.Timestamp).ToArray();
            foreach (var pos in positions)
            {
                if (startlocation == null)
                {
                    startlocation = pos.Coordinate;
                    continue;
                }

                if (!pos.Coordinate.IsUnknown)
                    distanceKM += startlocation.GetDistanceTo(pos.Coordinate) / 1000;
            }
            return distanceKM;
        }


    }
}
