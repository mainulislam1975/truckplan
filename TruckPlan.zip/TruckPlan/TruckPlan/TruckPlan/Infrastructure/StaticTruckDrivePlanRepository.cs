﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TruckPlan.Domain;

namespace TruckPlan.Infrastructure
{
    public class StaticTruckDrivePlanRepository : ITruckPlanDataRepository
    {
        IEnumerable<TruckDrivePlan> ITruckPlanDataRepository.GetTruckDrivePlans()
        {
            var truckPlans = new List<TruckDrivePlan>();
            truckPlans.Add(new TruckDrivePlan() { Id = 1, Driver = new Driver() { Id= 1, Name = "John", DateOfBirth = new DateTime(1995, 1, 1)  } , Truck =  new Truck() {  GpsDevice = new GpsPositionDataFeed.GpsDevice() { DeviceId = 1}, TruckId = 1}, started = DateTime.Now.AddMinutes(-15), completed = DateTime.Now });
            truckPlans.Add(new TruckDrivePlan() { Id = 2, Driver = new Driver() { Id = 2, Name = "Jesper", DateOfBirth = new DateTime(1995, 1, 1) }, Truck = new Truck() { GpsDevice = new GpsPositionDataFeed.GpsDevice() { DeviceId = 2 }, TruckId = 2 }, started = DateTime.Now.AddMinutes(-15), completed = DateTime.Now });
            truckPlans.Add(new TruckDrivePlan() { Id = 1, Driver = new Driver() { Id = 1, Name = "John", DateOfBirth = new DateTime(1965, 1, 1) }, Truck = new Truck() { GpsDevice = new GpsPositionDataFeed.GpsDevice() { DeviceId = 3 }, TruckId = 3 }, started = new DateTime(2018, 2, 3, 6,0,0), completed = new DateTime(2018, 2, 4, 1,0,0) });
            truckPlans.Add(new TruckDrivePlan() { Id = 2, Driver = new Driver() { Id = 2, Name = "Jesper", DateOfBirth = new DateTime(1965, 1, 1) }, Truck = new Truck() { GpsDevice = new GpsPositionDataFeed.GpsDevice() { DeviceId = 4 }, TruckId = 4 }, started = new DateTime(2018, 2, 5,5,0,0), completed = new DateTime(2018, 2, 6, 5,0,0) });
            return truckPlans; 
        }
    }
}
